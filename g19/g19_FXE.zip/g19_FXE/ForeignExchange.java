package ForeignExchange;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;
import org.json.JSONObject;

/**
 * The ForeignExchange class represents a foreign exchange system that allows
 * currency conversion and transaction fee calculation.
 * If you want to use JSON , you have to get the Lib json.jar and add it to your
 * Additionally use this https://exchangeratesapi.io/ to get the exchange rates
 * and save it as a JSON file
 * and uncomment Import org.json.JSONObject and function loadExchangeRates to
 * use it
 * 
 */
public class ForeignExchange {

    private Map<String, BigDecimal> exchangeRates;
    private BigDecimal transactionFee;
    private BigDecimal transactionLimit;

    /**
     * Constructs a ForeignExchange object with the specified transaction fee and
     * transaction limit.
     *
     * @param transactionFee   the transaction fee to be applied for each
     *                         transaction
     * @param transactionLimit the transaction limit for each transaction
     */
    public ForeignExchange() {
        this.exchangeRates = new HashMap<>();
        this.transactionFee = BigDecimal.ZERO; // Initialize with zero or a default value
        this.transactionLimit = BigDecimal.valueOf(10000); // Example default value
    }

    /**
     * Loads exchange rates from a file and populates the exchangeRates map.
     * 
     * @param filePath the path of the file containing the exchange rates
     *                 use Currency.json giving as a JSON File
     */
    public void loadExchangeRates(String filePath) {
        try {
            String content = new String(Files.readAllBytes(Paths.get(filePath)));
            System.out.println("Successfully loaded exchange rates from " + content);

            JSONObject exchangeRatesJson = new JSONObject(content);

            Iterator<String> keys = exchangeRatesJson.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                BigDecimal value = exchangeRatesJson.getBigDecimal(key);
                exchangeRates.put(key, value);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Saves the current exchange rates to the JSON file.
     *
     * @param filePath the path of the JSON file to update
     */
    public void saveExchangeRatesToFile(String filePath) {
        // Create a JSONObject from the exchangeRates map
        JSONObject json = new JSONObject(exchangeRates);

        // Convert the JSONObject to a pretty-printed JSON string
        String jsonString = json.toString(4); // '4' is the indentation level for pretty printing

        try {
            // Write the JSON string back to the file
            Files.write(Paths.get(filePath), jsonString.getBytes(), StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
            System.out.println("Exchange rates successfully saved to " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Failed to save exchange rates to " + filePath);
        }
    }

    /**
     * Displays all the available currency rates.
     */
    public void displayAllCurrencyRates() {
        System.out.println("Available Currency Rates:");
        for (Map.Entry<String, BigDecimal> entry : exchangeRates.entrySet()) {
            String currencyCode = entry.getKey();
            BigDecimal rate = entry.getValue();
            System.out.println(currencyCode + ": " + rate);
        }
    }

    /**
     * Adds a currency to the foreign exchange system.
     *
     * @param currency the currency to be added
     */
    /**
     * Adds or updates an exchange rate for a given currency code.
     * 
     * @param currencyCode The currency code to add or update the exchange rate for.
     * @param rate The exchange rate to be added or updated.
     * @param filePath The file path to save the exchange rates to.
     * @throws IllegalArgumentException If the currency code is null or empty, or if the rate is null or negative.
     */
    public void addExchangeRate(String currencyCode, BigDecimal rate, String filePath) {
        // Check if the currency code is null or empty
        if (currencyCode == null || currencyCode.trim().isEmpty()) {
            throw new IllegalArgumentException("Currency code cannot be null or empty.");
        }

        // Check if the rate is null or negative
        if (rate == null || rate.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Rate must be positive and non-null.");
        }

        // Check for duplicate currency codes
        if (exchangeRates.containsKey(currencyCode.toUpperCase())) {
            System.out.println("Currency code " + currencyCode + " already exists. Updating the rate.");
        } else {
            System.out.println("Exchange rate for " + currencyCode + " added with rate: " + rate);
        }

        // Add or update the exchange rate
        exchangeRates.put(currencyCode.toUpperCase(), rate);
        saveExchangeRatesToFile(filePath);
    }


    /**
     * Removes the exchange rate for the specified currency code from the exchangeRates map.
     * If the currency code is found, the exchange rate is removed and the updated exchangeRates
     * map is saved to the specified file path. If the currency code is not found, a message is
     * printed indicating that the exchange rate was not found.
     *
     * @param currencyCode the currency code for which to remove the exchange rate
     * @param filePath the file path to save the updated exchangeRates map
     */
    public void removeExchangeRate(String currencyCode, String filePath) {
        if (exchangeRates.containsKey(currencyCode.toUpperCase())) {
            exchangeRates.remove(currencyCode.toUpperCase());
            System.out.println("Exchange rate for " + currencyCode + " removed.");
            saveExchangeRatesToFile(filePath);
        } else {
            System.out.println("Exchange rate for " + currencyCode + " not found.");
        }
    }




    /**
     * Updates the exchange rate for the specified currency code.
     *
     * @param currencyCode the currency code for which the exchange rate is to be
     *                     updated
     * @param newRate      the new exchange rate to be set
     * @param filePath     the file path to save the updated exchange rates to
     */
    public void updateExchangeRate(String currencyCode, BigDecimal newRate, String filePath) {
        if (exchangeRates.containsKey(currencyCode.toUpperCase())) {
            exchangeRates.put(currencyCode.toUpperCase(), newRate);
            System.out.println("Exchange rate for " + currencyCode + " updated to: " + newRate);
            saveExchangeRatesToFile(filePath);
        } else {
            System.out.println("Exchange rate for " + currencyCode + " not found. No update made.");
        }
    }

    /**
     * Retrieves the exchange rate for the specified currency code.
     *
     * @param currencyCode the currency code for which the exchange rate is to be
     *                     retrieved
     * @return the exchange rate for the specified currency code, or BigDecimal.ZERO
     *         if not found
     */
    public BigDecimal getExchangeRate(String currencyCode) {
        return exchangeRates.getOrDefault(currencyCode.toUpperCase(), BigDecimal.ZERO);
    }

   
    /**
     * Sets the exchange rate for a given currency code.
     * 
     * @param currencyCode The currency code to set the exchange rate for.
     * @param rate The exchange rate to set.
     * @param filePath The file path to save the exchange rates to.
     * @throws IllegalArgumentException If the currency code is null or empty, or if the rate is null or negative.
     */
    public void setExchangeRate(String currencyCode, BigDecimal rate, String filePath) {
        // Check if the currency code is null or empty
        if (currencyCode == null || currencyCode.trim().isEmpty()) {
            throw new IllegalArgumentException("Currency code cannot be null or empty.");
        }

        // Check if the rate is null or negative
        if (rate == null || rate.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Rate must be positive and non-null.");
        }

        // Update the exchange rate
        exchangeRates.put(currencyCode.toUpperCase(), rate);
        saveExchangeRatesToFile(filePath);
        System.out.println("Exchange rate for " + currencyCode + " set to " + rate + ".");
    }


    /**
     * Deletes the exchange rate for a specific currency code.
     * 
     * @param currencyCode The currency code to delete the exchange rate for.
     * @param filePath The file path to save the updated exchange rates.
     * @return A message indicating the result of the deletion.
     *         - If the currency code is null or empty, returns "Currency code cannot be null or empty."
     *         - If the currency code exists in the map and is successfully deleted, returns "Exchange rate for {currencyCode} has been successfully deleted."
     *         - If the currency code does not exist in the map, returns "Exchange rate for {currencyCode} not found. No deletion performed."
     */
    public String deleteExchangeRate(String currencyCode, String filePath) {
        if (currencyCode == null || currencyCode.trim().isEmpty()) {
            return "Currency code cannot be null or empty.";
        }

        // Convert to uppercase to ensure consistent case for comparison
        currencyCode = currencyCode.toUpperCase();

        // Check if the currency code exists in the map before attempting to remove it
        if (exchangeRates.containsKey(currencyCode)) {
            exchangeRates.remove(currencyCode);
            saveExchangeRatesToFile(filePath);
            return "Exchange rate for " + currencyCode + " has been successfully deleted.";
        } else {
            return "Exchange rate for " + currencyCode + " not found. No deletion performed.";
        }
    }

    /**
     * Converts the specified amount from one currency to another, taking into
     * account transaction fees.
     *
     * @param amount           the amount to be converted
     * @param fromCurrencyCode the currency code of the source currency
     * @param toCurrencyCode   the currency code of the target currency
     * @param transactionFee   the transaction fee to be applied for the conversion
     * @return the converted amount, after deducting the transaction fee
     */
    public BigDecimal convertToCurrency(BigDecimal amount, String fromCurrencyCode, String toCurrencyCode,
            BigDecimal transactionFee) {
        BigDecimal fromRate = getExchangeRate(fromCurrencyCode);
        BigDecimal toRate = getExchangeRate(toCurrencyCode);
        BigDecimal convertedAmount;

        // Convert from source currency to SGD if source is not SGD, then from SGD to
        // target currency
        if (!fromCurrencyCode.equals("SGD") && !toCurrencyCode.equals("SGD")) {
            // Convert source amount to SGD
            BigDecimal sgdAmount = amount.multiply(fromRate).divide(getExchangeRate("SGD"), 2, RoundingMode.HALF_UP);
            // Apply transaction fee in SGD
            BigDecimal transactionFeeAmount = calculateTransactionFee(sgdAmount);
            System.out.println("Transaction Fee Amount: " + transactionFeeAmount + " SGD");
            // Convert SGD amount to target currency, after deducting transaction fee
            convertedAmount = sgdAmount.subtract(transactionFeeAmount).multiply(toRate);
        } else if (fromCurrencyCode.equals("SGD")) {
            // Direct conversion from SGD to target currency, apply fee in SGD
            BigDecimal transactionFeeAmount = calculateTransactionFee(amount);
            System.out.println("Transaction Fee Amount: " + transactionFeeAmount + " SGD");
            convertedAmount = amount.subtract(transactionFeeAmount).multiply(toRate);
        } else {
            // Direct conversion from source currency to SGD, apply fee in source currency
            BigDecimal transactionFeeAmount = calculateTransactionFee(amount);
            System.out.println("Transaction Fee Amount: " + transactionFeeAmount + " " + fromCurrencyCode);
            convertedAmount = amount.subtract(transactionFeeAmount).multiply(fromRate).divide(getExchangeRate("SGD"), 2,
                    RoundingMode.HALF_UP);
        }

        System.out.println("Converted amount after deduction: " + convertedAmount + " " + toCurrencyCode);

        return convertedAmount;
    }

    /**
     * Retrieves the transaction fee amount.
     *
     * @return the transaction fee amount
     */
    public BigDecimal getTransactionFeeAmount() {
        return transactionFee;
    }


    /**
     * Sets the transaction fee for foreign exchange transactions.
     *
     * @param transactionFee the transaction fee to be set
     * @throws IllegalArgumentException if the transaction fee is null or negative
     */
    public void setTransactionFee(BigDecimal transactionFee) {
        if (transactionFee == null) {
            throw new IllegalArgumentException("Transaction fee cannot be null.");
        }
        if (transactionFee.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Transaction fee cannot be negative.");
        }
        this.transactionFee = transactionFee;
    }

    /**
     * Calculates the transaction fee for the specified amount.
     *
     * @param amount the amount for which the transaction fee is to be calculated
     * @return the transaction fee
     */

    public BigDecimal calculateTransactionFee(BigDecimal amount) {
        if (amount == null) {
            throw new IllegalArgumentException("Amount cannot be null.");
        }
        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Amount cannot be negative.");
        }
        if (transactionFee == null) {
            throw new IllegalStateException("Transaction fee has not been set.");
        }
        return transactionFee.multiply(amount);
    }

}