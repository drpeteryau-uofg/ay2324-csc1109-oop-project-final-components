package CreditCard;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.function.BiFunction;
import java.util.Random;

/**
 * The CreditCard class represents a credit card with its properties and methods.
 * A CreditCard has attributes card number, type, holder name, credit limit, amount owed, expiry date, cvv and the card status.
 * This class has methods to manage the card, including changing card status, changing credit limit and, making payment
 */
public class CreditCard {
    private String cardNumber;
    private String cardType;
    private String cardHolder;
    private int creditLimit;
    private BigDecimal amountOwed;
    private LocalDate expiryDate;
    private String cvv;
    private boolean isBlocked;
    private boolean isActive;

    /**
     * Constructor to create new CreditCard object with the specified parameters.
     * 
     * @param cardNumber    The unique identifier for the card number
     * @param cardType      The type of credit card (example: Mastercard, Visa)
     * @param cardHolder    The name of the credit card owner
     * @param creditLimit   The credit card limit
     * @param amountOwed    The amount owed to reflect the fact that credit cards are a form of debt
     * @param expiryDate    The expiration date of the credit card
     * @param cvv           The CVV of the credit card
     */
    public CreditCard(String cardNumber, String cardType, String cardHolder, int creditLimit, BigDecimal amountOwed, LocalDate expiryDate, String cvv) {
        this.cardNumber = cardNumber;
        this.cardType = cardType;
        this.cardHolder = cardHolder;
        this.creditLimit = creditLimit;
        this.amountOwed = amountOwed;
        this.expiryDate = expiryDate;
        this.cvv = cvv;
        this.isBlocked = false;
        this.isActive = true;
    }

    /**
     * Retrieves the credit card number
     * @return The card number
     */
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * Sets the credit card number
     * @param cardNumber The new number to set
     */
    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    /**
     * Retrieves the type of credit card
     * @return The card type
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * Sets the type of credit card
     * @param cardType The new type to set
     */
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    /**
     * Retrieves the name of the credit card holder
     * @return The card holder name
     */
    public String getCardHolder() {
        return cardHolder;
    }

    /**
     * Sets the name of the credit card holder
     * @param cardHolder The new holder name to set
     */
    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    /**
     * Retrieves the credit card limit
     * @return The credit limit
     */
    public int getCreditLimit() {
        return creditLimit;
    }

    /**
     * Sets the credit card limit
     * @param creditLimit The new limit to set
     */
    public void setCreditLimit(int creditLimit) {
        this.creditLimit = creditLimit;
    }

    /**
     * Retrieves the amount owed in the credit card
     * @return The amount owed in card
     */
    public BigDecimal getAmountOwed() {
        return amountOwed;
    }

    /**
     * Sets the amount owed in the credit card
     * @param amountOwed The new amount to set
     */
    public void setAmountOwed(BigDecimal amountOwed) {
        this.amountOwed = amountOwed;
    }

    /**
     * Retrieves the expiration date of the credit card
     * @return The card expiration date
     */
    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    /**
     * Sets the expiration date of the credit card
     * @param expiryDate The new date to set
     */
    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    /**
     * Retrieves the credit card CVV
     * @return The card CVV
     */
    public String getCvv() {
        return cvv;
    }

    /**
     * Sets the credit card CVV
     * @param cvv The new CVV to set
     */
    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    /**
     * Checks whether the credit card is blocked
     * @return false if the credit card is not blocked
     */
    public boolean isCardBlocked() {
        return isBlocked;
    }

    /**
     * Sets the status of the credit card to unblocked
     * isBlocked = false if the card is blocked
     */
    public void unblockCard() {
        // check if card is unblocked
        if (this.isBlocked == false) {
            System.out.println("This card is not blocked.");
        } else {
            this.isBlocked = false;
            System.out.println("Card unblocked");
        }
    }

    /**
     * Sets the status of the credit card to blocked
     * isBlocked = true
     */
    public void blockCard() {
        this.isBlocked = true;
        System.out.println("Card blocked");
    }

    /**
     * Checks whether the credit card is activated
     * @return true if the credit card is active
     */
    public boolean isCardActive() {
        return isActive;
    }

    /**
     * Sets the status of the credit card to activated
     * isActive = true if the card is not activated
     */
    public void activateCard() {
        if (this.isActive == true) {
            System.out.println("This card is already activated");
        } else {
            this.isActive = true;
            System.out.println("Card activated");
        }
    }

    /**
     * Sets the status of the credit card to deactivated
     * isActive = false if the card is not blocked
     */
    public void deactivateCard() {
        if (this.isBlocked == true) {
            System.out.println("This card is blocked, please unblock the card to deactivate");
        } else {
            this.isActive = false;
            System.out.println("Card deactivated");
        }
    }

    /**
     * Generates a card number string
     * Note: This function does not ensure that the generated CVV is unique, the user needs to check for uniqueness when implementing this function
     * @return a randomly generated card number of 16 digits
     */
    public String generateCardNumber() {
        Random random = new Random();
        StringBuilder cardNumberBuilder = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            cardNumberBuilder.append(random.nextInt(10));
        }
        return cardNumberBuilder.toString();
    }

    /**
     * Generates a CVV string
     * Note: This function does not ensure that the generated CVV is unique, the user needs to check for uniqueness when implementing this function
     * @return a randomly generated cvv of 3 digits
     */
    public String generateCVV() {
        Random random = new Random();
        StringBuilder cvvBuilder = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            cvvBuilder.append(random.nextInt(10));
        }
        return cvvBuilder.toString();
    }

    /**
     * Change the credit limit of the credit card
     * Pass a positive amount to increase or a negative amount to decrease it
     * 
     * @param amount The amount to increse or decrease the limit
     */
    public void changeCreditLimit(int amount) {
        creditLimit += amount;
        
        if (amount > 0) {
            System.out.println("Credit limit increased by $" + amount); 
        } else {
            System.out.println("Credit limit decreased by $" + amount); 
        }
    }

    /**
     * Making a payment with the credit card
     * The payment is successful if the amount owed in the card is sufficient. 
     * Amount owed refers to the remaining available credit.
     * 
     * @param amount The amount to deduct from the card
     * @return true if the payment is successul
     */
    public boolean makePayment(BigDecimal amount) {
        if (!isCardBlocked() && amount.compareTo(amountOwed) <= 0) {
            amountOwed = amountOwed.subtract(amount);
            System.out.println("Payment successful: $" + amount);
            return true;
        } else {
            System.out.println("Payment unsuccessful: Insufficient balance or card is blocked.");
            return false;
        }
    }

    /**
     * Displays information of the credit card
     */
    public void displayCardInfo() {
        System.out.println("Card Holder Name: " + cardHolder + 
                            "\nCard Number: " + cardNumber + 
                            "\nCard Type: " + cardType + 
                            "\nExpiration Date: " + expiryDate + 
                            "\nCVV: " + cvv + 
                            "\nAmount Owed: $" + amountOwed.setScale(2, BigDecimal.ROUND_HALF_UP) +
                            "\nCredit Limit: $" + creditLimit + 
                            "\nActive Status: $" + isActive + 
                            "\nBlock Status: " + isBlocked);
    }

}