package Insurance;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * The Insurance class represents an insurance policy.
 * It includes attributes such as insurance ID, type, coverage limit, premium, and claims.
 * This class provides methods to manage the insurance policy, including creating claims and calculating total claims.
 */
public class Insurance {
    private int insuranceID;
    private String type;
    private BigDecimal coverageLimit;
    private BigDecimal premium;
    private String paymentSchedule;
    private Boolean isActive;
    private HashMap<Integer, Claims> claims;

    /**
     * Constructs an Insurance object with the specified parameters.
     *
     * @param insuranceID      The unique identifier for the insurance policy.
     * @param type             The type of insurance policy.
     * @param coverageLimit    The initial coverage limit for the insurance policy.
     * @param premium          The premium amount for the insurance policy.
     * @param paymentSchedule  The payment schedule of the insurance policy.
     */
    public Insurance(int insuranceID, String type, BigDecimal coverageLimit, BigDecimal premium, String paymentSchedule) {
        this.insuranceID = insuranceID;
        this.type = type;
        this.coverageLimit = coverageLimit;
        this.premium = premium;
        this.paymentSchedule = paymentSchedule;
        this.isActive = true;
        this.claims = new HashMap<Integer, Claims>();
    }

    /**
     * Retrieves the unique identifier for the insurance policy.
     *
     * @return The insurance policy's unique identifier.
     */
    public int getInsuranceID() {
        return insuranceID;
    }

    /**
     * Sets the unique identifier for the insurance policy.
     *
     * @param insuranceID The new unique identifier to set.
     */
    public void setInsuranceID(int insuranceID) {
        this.insuranceID = insuranceID;
    }

    /**
     * Retrieves the type of the insurance policy.
     *
     * @return The type of the insurance policy.
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type of the insurance policy.
     *
     * @param type The new type to set.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Retrieves the coverage limit for the insurance policy.
     *
     * @return The coverage limit for the insurance policy.
     */
    public BigDecimal getCoverageLimit() {
        return coverageLimit;
    }

    /**
     * Sets the coverage limit for the insurance policy.
     *
     * @param coverageLimit The new coverage limit to set.
     */
    public void setCoverageLimit(BigDecimal coverageLimit) {
        this.coverageLimit = coverageLimit;
    }

    /**
     * Retrieves the current coverage limit for the insurance policy.
     * The current coverage limit is adjusted by subtracting the total amount of accepted claims.
     *
     * @return The adjusted coverage limit for the insurance policy.
     */
    public BigDecimal getCurrentCoverageLimit() {
        return coverageLimit.subtract(getTotalAcceptedClaims());
    }

    /**
     * Retrieves the premium amount for the insurance policy.
     *
     * @return The premium amount for the insurance policy.
     */
    public BigDecimal getPremium() {
        return premium;
    }

    /**
     * Sets the premium amount for the insurance policy.
     *
     * @param premium The new premium amount to set.
     */
    public void setPremium(BigDecimal premium) {
        this.premium = premium;
    }

    /**
     * Retrieves the payment schedule for the insurance policy
     *
     * @return  The payment schedule of the insurance policy
     */
    public String getPaymentSchedule() {
        return this.paymentSchedule;
    }

    /**
     * Sets the payment schedule for the insurance policy
     *
     * @param paymentSchedule   The new payment schedule to set
     */
    public void setPaymentSchedule(String paymentSchedule) {
        this.paymentSchedule = paymentSchedule;
    }

    /**
     * Checks whether the insurance policy is active.
     *
     * @return true if the insurance policy is active.
     */
    public Boolean getIsActive() {
        return isActive;
    }

    /**
     * Sets the active status of the insurance policy.
     *
     * @param isActive The new active status to set.
     */
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    /**
     * Creates a claim for the insurance policy with the specified claim date and amount.
     * The claim is accepted if the coverage limit is sufficient.
     *
     * @param claimDate   The date when the claim is created.
     * @param claimAmount The amount of the claim.
     */
    public void createClaim(LocalDate claimDate, BigDecimal claimAmount) {
        Claims claim = new Claims(getNumberOfClaims()+1, claimDate, claimAmount);
        this.claims.put(getNumberOfClaims()+1, claim);
    }

    /**
     * Creates a claim for the insurance policy with the current date and the specified amount.
     * The claim is accepted if the coverage limit is sufficient.
     *
     * @param claimAmount The amount of the claim.
     */
    public void createClaim(BigDecimal claimAmount) {
        LocalDate localDate = LocalDate.now();
        Claims claim = new Claims(getNumberOfClaims()+1, localDate, claimAmount);
        this.claims.put(getNumberOfClaims()+1, claim);
    }

    /**
     * Approves a claim based on the insurance policy's current coverage limit.
     *
     * @param claim The claim to be approved or rejected.
     * @return true if the claim is approved, false if the claim is not found or coverageLimit is insufficient.
     */
    public boolean approveClaim(Claims claim) {
        for (Claims claimCheck : this.claims.values()) {
            if (claimCheck.getClaimDate() == claim.getClaimDate() && claimCheck.claimsID == claim.getClaimsID()) {
                if (this.getCurrentCoverageLimit().compareTo(claim.getClaimsAmount()) > 0) {
                    claim.setClaimApproved();
                    return true;
                }
                break;
            }
        }
        return false;
    }

    /**
     * Approves a claim based on the insurance policy's current coverage limit using the claim's unique identifier.
     *
     * @param claimID The unique identifier of the claim to be approved.
     * @return true if the claim is approved, false if the claim ID is not found or coverageLimit is insufficient.
     */
    public boolean approveClaim(int claimID) {
        for (Claims claim : this.claims.values()) {
            if (claim.getClaimsID() == claimID) {
                if (this.getCurrentCoverageLimit().compareTo(claim.getClaimsAmount()) > 0) {
                    claim.setClaimApproved();
                    return true;
                }
                break;
            }
        }
        return false;
    }

    /**
     * Rejects a claim.
     *
     * @param claim The claim to be rejected.
     * @return true if the claim is rejected, false if the claim is not found.
     */
    public boolean denyClaim(Claims claim) {
        for (Claims claimCheck : this.claims.values()) {
            if (claimCheck.getClaimDate() == claim.getClaimDate() && claimCheck.claimsID == claim.getClaimsID()) {
                claim.setClaimDenied();
                return true;
            }
        }
        return false;
    }

    /**
     * Rejects a claim using the claim's unique identifier.
     *
     * @param claimID The unique identifier of the claim to be rejected.
     * @return true if the claim is rejected, false if the claim ID is not found.
     */
    public boolean denyClaim(int claimID) {
        for (Claims claim : claims.values()) {
            if (claim.getClaimsID() == claimID) {
                claim.setClaimDenied();
                return true;
            }
        }
        return false;
    }

    /**
     * Calculates the total amount of accepted claims associated with the insurance policy.
     *
     * @return The total amount of accepted claims.
     */
    public BigDecimal getTotalAcceptedClaims() {
        BigDecimal total = BigDecimal.valueOf(0);
        for (Claims claim : claims.values()) {
            if (claim.getStatus() == "Approved") {
                total = total.add(claim.getClaimsAmount());
            }
        }
        return total;
    }

    /**
     * Calculates the total amount of all claims associated with the insurance policy, regardless of acceptance status.
     *
     * @return The total amount of all claims.
     */
    public BigDecimal getTotalClaims() {
        BigDecimal total = BigDecimal.valueOf(0);
        for (Claims claim : claims.values()) {
            total = total.add(claim.getClaimsAmount());
        }
        return total;
    }

    /**
     * Retrieves the number of claims associated with the insurance policy.
     *
     * @return The number of claims.
     */
    public int getNumberOfClaims() {
        return claims.size();
    }

    /**
     * Retrieves a specific claim associated with the insurance policy based on its unique identifier.
     *
     * @param claimID The unique identifier of the claim to retrieve.
     * @return The claim with the specified identifier.
     */
    public Claims getClaimByID(int claimID) {
        return claims.get(claimID);
    }

    /**
     * Retrieves a list of claims associated with the insurance policy that have an exact match to the specified date.
     *
     * @param date The exact date to match claims against.
     * @return A list of claims matching the specified date.
     */
    public ArrayList<Claims> getClaimByExactDate(LocalDate date) {
        ArrayList<Claims> listOfClaims= new ArrayList<Claims>();
        for (Claims claim : claims.values()) {
            if (claim.claimDate.equals(date)) {
                listOfClaims.add(claim);
            }
        }
        return listOfClaims;
    }

    /**
     * Retrieves a list of claims associated with the insurance policy that occurred after the specified date.
     *
     * @param date The date to compare against for claims occurring after it.
     * @return A list of claims occurring after the specified date.
     */
    public ArrayList<Claims> getClaimAfterDate(LocalDate date) {
        ArrayList<Claims> listOfClaims= new ArrayList<Claims>();
        for (Claims claim : claims.values()) {
            if (claim.claimDate.isAfter(date)) {
                listOfClaims.add(claim);
            }
        }
        return listOfClaims;
    }

    /**
     * Retrieves a list of claims associated with the insurance policy that occurred before the specified date.
     *
     * @param date The date to compare against for claims occurring before it.
     * @return A list of claims occurring before the specified date.
     */
    public ArrayList<Claims> getClaimBeforeDate(LocalDate date) {
        ArrayList<Claims> listOfClaims= new ArrayList<Claims>();
        for (Claims claim : claims.values()) {
            if (claim.claimDate.isBefore(date)) {
                listOfClaims.add(claim);
            }
        }
        return listOfClaims;
    }

    /**
     * Displays information about the insurance policy and associated claims.
     */
    public void displayInfo() {
        if (claims.size() > 0) {
            System.out.println("List of claims:");
            System.out.print(String.format("%-10s", "Claim ID"));
            System.out.print(String.format("%-20s", "Claim Date"));
            System.out.print(String.format("%-20s", "Claim Amount"));
            System.out.print(String.format("%-10s\n", "Claim Status"));
            for (Claims claim : claims.values()) {
                System.out.print(String.format("%-10s", String.valueOf(claim.getClaimsID())));
                System.out.print(String.format("%-20s", claim.getClaimDate()));
                System.out.print(String.format("%-20s", claim.getClaimsAmount()));
                System.out.print(String.format("%-10s\n", claim.getStatus()));
            }
        }
        System.out.println("Insurance ID: " + getInsuranceID());
        System.out.println("Type: " + getType());
        System.out.println("Total coverage: " + getCoverageLimit());
        System.out.println("Remaining coverage: " + getCurrentCoverageLimit());
        System.out.println("Premium: " + getPremium());
        System.out.println("Active plan: " + getIsActive());
    }
    
    /**
     * Displays information about the insurance policy and a list of associated claims.
     *
     * @param listOfClaims The list of claims to be displayed.
     */
    public void displayInfo(ArrayList<Claims> listOfClaims) {
        System.out.println("List of claims:");
        System.out.print(String.format("%-10s", "Claim ID"));
        System.out.print(String.format("%-20s", "Claim Date"));
        System.out.print(String.format("%-20s", "Claim Amount"));
        System.out.print(String.format("%-10s\n", "Claim Status"));
        for (Claims claim : listOfClaims) {
            System.out.print(String.format("%-10s", String.valueOf(claim.getClaimsID())));
            System.out.print(String.format("%-20s", claim.getClaimDate()));
            System.out.print(String.format("%-20s", claim.getClaimsAmount()));
            System.out.print(String.format("%-10s\n", claim.getStatus()));
        }
        System.out.println("Insurance ID: " + getInsuranceID());
        System.out.println("Type: " + getType());
        System.out.println("Total coverage: " + getCoverageLimit());
        System.out.println("Remaining coverage: " + getCurrentCoverageLimit());
        System.out.println("Premium: " + getPremium());
        System.out.println("Payment plan: " + getPaymentSchedule());
        System.out.println("Active plan: " + getIsActive());
    }

    /**
     * The Claims class represents an insurance claim.
     * It includes attributes such as claim ID, claim date, claim amount, and acceptance status.
     * This class provides methods to access and modify claim details.
     */
    public static class Claims {
        int claimsID;
        LocalDate claimDate;
        BigDecimal claimsAmount;
        String status;

        /**
         * Constructs a Claims object with the specified parameters.
         *
         * @param claimsID      The unique identifier for the claim.
         * @param claimDate     The date when the claim was made.
         * @param claimsAmount  The amount associated with the claim.
         */
        public Claims(int claimsID, LocalDate claimDate, BigDecimal claimsAmount) {
            this.claimsID = claimsID;
            this.claimDate = claimDate;
            this.claimsAmount = claimsAmount;
            this.status = "Pending";
        }

        /**
         * Retrieves the unique identifier for the claim.
         *
         * @return The claim ID.
         */
        public int getClaimsID() {
            return claimsID;
        }

        /**
         * Retrieves the date when the claim was made.
         *
         * @return The claim date.
         */
        public LocalDate getClaimDate() {
            return claimDate;
        }

        /**
         * Retrieves the amount of the claim.
         *
         * @return The claim amount.
         */
        public BigDecimal getClaimsAmount() {
            return this.claimsAmount;
        }

        /**
         * Checks the status of the claim.
         *
         * @return The status of the claim.
         */
        public String getStatus() {
            return this.status;
        }

        /**
         * Sets the status of the claim to Approved.
         *
         * @return True if the claim has been set, false otherwise
         */
        public boolean setClaimApproved() {
            if (this.status == "Pending") {
                this.status = "Approved";
                return true;
            }
            return false;
        }

        /**
         * Sets the status of the claim to Denied.
         *
         * @return True if the claim has been set, false otherwise
         */
        public boolean setClaimDenied() {
            if (this.status == "Pending") {
                this.status = "Denied";
                return true;
            }
            return false;
        }
    }
}
