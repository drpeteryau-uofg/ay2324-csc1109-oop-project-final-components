/**
 * Author: Corey Siah
 * E-mail: 2301072@sit.singaporetech.edu.sg
 * Date: 210324
 *
 * Description: The Branch class which provides
 * methods for Branch operations
 */

package Project.CsvTesting;

import java.util.UUID;

/**
 * A class to represent a blueprint of a branch of a bank.
 */
public class Branch {
    private UUID branchID; // Represents the branch ID
    private String branchName; // Represents the branch Name
    private String branchRegion; // Represents the branch Region (e.g. "North, South, East, West")
    private String branchAddress; // Represents the branch address (e.g. "City Hall #05-21")
    private int branchFaxNumber; // Represents the branch fax number
    private String servicesOffered; // Represents the types of services offered by the branch
    private String openingHours; // Represents the branch opening hours (e.g. "Mon-Fri 9:00-17:00, Sat 10:00-14:00")

    /**
     * Constructs a new Branch instance.
     *
     * @param branchName The name of the branch.
     * @param branchRegion The region where the branch is located.
     * @param branchAddress The physical address of the branch.
     * @param branchFaxNumber The fax number for the branch.
     * @param servicesOffered The types of services offered by the branch.
     * @param openingHours The opening hours of the branch.
     */
    public Branch(String branchName, String branchRegion, String branchAddress, int branchFaxNumber, String servicesOffered, String openingHours) {
        this.branchID = UUID.randomUUID();
        this.branchName = branchName;
        this.branchRegion = branchRegion;
        this.branchAddress = branchAddress;
        this.branchFaxNumber = branchFaxNumber;
        this.servicesOffered = servicesOffered;
        this.openingHours = openingHours;
    }

    /**
     * Sets the branch's UUID.
     */
    public void setBranchID(UUID branchID) {
        this.branchID = branchID;
    }

    /**
     * Sets the branch's name.
     */
    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    /**
     * Sets the branch's region.
     */
    public void setBranchRegion(String branchRegion) {
        this.branchRegion = branchRegion;
    }

    /**
     * Sets the branch's physical address.
     */
    public void setBranchAddress(String branchAddress) {
        this.branchAddress = branchAddress;
    }

    /**
     * Sets the branch's fax number.
     */
    public void setBranchFaxNumber(int branchFaxNumber) {
        this.branchFaxNumber = branchFaxNumber;
    }

    /**
     * Sets the types of services offered by the branch.
     */
    public void setServicesOffered(String servicesOffered) {
        this.servicesOffered = servicesOffered;
    }

    /**
     * Sets the opening hours of the branch.
     */
    public void setOpeningHours(String openingHours) {
        this.openingHours = openingHours;
    }

    /**
     * The relevant information shown when the branch is printed.
     */
    @Override
    public String toString() {
        // Overrides the print method to return the Branch object's essential information instead when attempting to print a Branch object
        return "Branch ID: " + this.branchID + "\nBranch Name: " + this.branchName + "\nBranch Region: " + this.branchRegion + "\nBranch Address: " + this.branchAddress + "\nBranch Fax Number: " + this.branchFaxNumber + "\nServices Offered: " + this.servicesOffered + "\nOpening Hours: " + this.openingHours;
    }

    /**
     * Gets the branch's identification number.
     */
    public UUID getBranchID() {
        return this.branchID;
    }

    /**
     * Gets the branch's name.
     */
    public String getBranchName() {
        return this.branchName;
    }

    /**
     * Gets the branch's region.
     */
    public String getBranchRegion() {
        return this.branchRegion;
    }

    /**
     * Gets the branch's physical address.
     */
    public String getBranchAddress() {
        return this.branchAddress;
    }

    /**
     * Gets the branch's fax number.
     */
    public int getBranchFaxNumber() {
        return this.branchFaxNumber;
    }

    /**
     * Gets the types of services offered by the branch.
     */
    public String getServicesOffered() {
        return this.servicesOffered;
    }

    /**
     * Gets the opening hours of the branch.
     */
    public String getOpeningHours() {
        return this.openingHours;
    }
}
