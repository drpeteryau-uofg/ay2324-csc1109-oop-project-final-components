If you are having troubles with any of the classes, email me at:
2301072@sit.singaporetech.edu.sg

JavaDocs locations
Branch 544: JavaDocs > Project > CsvTesting > Branch.html
CreditCard 511: JavaDocs > CreditCard.html
CurrencyExchange 522: JavaDocs > CurrencyExchange.html