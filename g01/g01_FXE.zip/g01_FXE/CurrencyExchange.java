/**
 * Author: Tee Yu Cheng
 * E-mail: 2300884@sit.singaporetech.edu.sg
 * Date: 20240214
 *
 * Description: The Currency class which provides 
 * methods for currency exchange operations.
 */

import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Set;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

/**
 * A class that provides methods for currency exchange operations.
 */
public class CurrencyExchange {

    // The path to the JSON file containing exchange rates (offline mode)
    private static final String JSON_FILE_PATH = "nintest/exchange_rates.json";

    // ================================================================== //
    //                            Get Methods                             //
    //           These methods will return some values or data            //
    // ================================================================== //

    /**
     * Gets the exchange rate for the given source and target currencies from an online API.
     *
     * @param sourceCurrency the source currency code
     * @param targetCurrency the target currency code
     * @return the exchange rate, or null if an error occurs
     */
    public Double getOnlineExchangeRate(String sourceCurrency, String targetCurrency) {
        // Create a new HTTP Client
        HttpClient httpClient = HttpClients.createDefault();
        
        // Create a new HTTP GET request with API URL
        HttpGet request = new HttpGet("https://open.er-api.com/v6/latest/" + sourceCurrency);


        try {
            // Execute the request and get the response
            HttpResponse response = httpClient.execute(request);
            
            String responseBody = EntityUtils.toString(response.getEntity());

            JSONObject jsonResponse = new JSONObject(responseBody);
            
            JSONObject rates = jsonResponse.getJSONObject("rates");

            Double exchangeRate = rates.getDouble(targetCurrency);
            
            return exchangeRate;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        
    }
    
    /**
     * Gets the set of all available currencies from an online API.
     *
     * @return the set of available currencies, or null if an error occurs
     */
    public Set<String> getOnlineAvailableCurrencies(){
        HttpClient httpClient = HttpClients.createDefault();
        HttpGet request = new HttpGet("https://open.er-api.com/v6/latest/SGD");

        try {

            HttpResponse response = httpClient.execute(request);
            String responseBody = EntityUtils.toString(response.getEntity());

            JSONObject jsonResponse = new JSONObject(responseBody);
            
            //Just the Object Keys (Currencies)
            JSONObject rates = jsonResponse.getJSONObject("rates");

            return rates.keySet();
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Checks if the given currency is available for exchange using an online API.
     *
     * @param currency the currency code to check
     * @return true if the currency is available, false otherwise
     */ 
    public Boolean getOnlineCurrencyAvailability(String currency) {

        //Get the Currencies Set
        Set<String> availableCurrencies = getOnlineAvailableCurrencies();
        //Check if the currency is available in the set
        return availableCurrencies != null && availableCurrencies.contains(currency.toUpperCase());
    }

    /**
     * Gets the exchange rate for the given source and target currencies from a local JSON file.
     *
     * @param sourceCurrency the source currency code
     * @param targetCurrency the target currency code
     * @return the exchange rate, or null if an error occurs
     */    
    public Double getExchangeRate(String sourceCurrency, String targetCurrency) {
        try {

            // Read the JSON file
            JSONObject jsonObject = new JSONObject(getJSONString());
            // Extract the rates object
            JSONObject rates = jsonObject.getJSONObject("rates"); 

            // Get the exchange rate for the target currency
            Double exchangeRate = rates.getDouble(targetCurrency.toUpperCase());

            // If the source currency is not SGD, convert the exchange rate 
            // Example: 1 SGD = 3.0 MYR, 1 MYR = 0.333333 SGD
            // Example: 1 MYR = 0.25 USD, 1 USD = MYR 4.0
            if(!sourceCurrency.equals("SGD")) {
                Double rateSwitch = exchangeRate / rates.getDouble(sourceCurrency.toUpperCase());
                BigDecimal bdRate = BigDecimal.valueOf(rateSwitch).setScale(6, RoundingMode.DOWN); // Hehehehe, just going to talk a little service fee
                Double convertedRate = bdRate.doubleValue();
            
                return convertedRate;
            }

            return exchangeRate;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Gets the set of all available currencies from a local JSON file.
     *
     * @return the set of available currencies, or null if an error occurs
     */
    public Set<String> getAvailableCurrencies(){
        
        try {

            JSONObject jsonObject = new JSONObject(getJSONString());
            
            //Just the Object Keys (Currencies)
            JSONObject rates = jsonObject.getJSONObject("rates");

            return rates.keySet();

        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Checks if the given currency is available for exchange using a local JSON file.
     *
     * @param currency the currency code to check
     * @return true if the currency is available, false otherwise
     */
    public Boolean getCurrencyAvailability(String currency) {

        //Get the Currencies Set
        Set<String> availableCurrencies = getAvailableCurrencies();
        //Check if the currency is available in the set
        return availableCurrencies != null && availableCurrencies.contains(currency.toUpperCase());
    }

    /**
     * Reads the content of the local CurrencyRate JSON file, convert and returns it as a string.
     *
     * @return the content of the JSON file
     */
    public String getJSONString(){
        StringBuilder builder = new StringBuilder();
        try (BufferedReader buffer = new BufferedReader(
                 new FileReader(JSON_FILE_PATH))) {
 
            String str;
 
            // Condition check via buffer.readLine() method
            // holding true up to that the while loop runs
            while ((str = buffer.readLine()) != null) {
 
                builder.append(str).append("\n");
            }
        }
 
        // Catch block to handle the exceptions
        catch (IOException e) {
 
            // Print the line number here exception occurred
            // using printStackTrace() method
            e.printStackTrace();
        }
 
        // Returning a string
        return builder.toString();
    }

    // ================================================================== //
    //                          Check Methods                             //
    //           These methods will display result in console             //
    // ================================================================== //

    /**
     * Checks and prints the exchange rate for the given source and target currencies.
     *
     * @param sourceCurrency the source currency code
     * @param targetCurrency the target currency code
     */
    public void checkExchangeRate(String sourceCurrency, String targetCurrency){
        Double exchangeRate = getExchangeRate(sourceCurrency, targetCurrency);
        System.out.println("Please Note that this is an offline exchange rate (Updated: 13/2/2024)");
        System.out.println("1 " + sourceCurrency + " equals " + exchangeRate + " " + targetCurrency);
    }

    // ================================================================== //
    //                          Lazy Methods                              //
    //          These methods will return some values or data             //
    // ================================================================== //

    /**
     * A lazy and direct method to convert currency and return amount in target currency.
     *
     * @param sourceCurrency the source currency code
     * @param targetCurrency the target currency code
     * @param amount the amount to convert
     * @return the converted amount in the target currency
     */
    public Double convertCurrency(String sourceCurrency, String targetCurrency, Double amount){
        Double exchangeRate = getExchangeRate(sourceCurrency, targetCurrency);
        Double convertedAmount = amount * exchangeRate;
        BigDecimal bdAmount = BigDecimal.valueOf(convertedAmount).setScale(2, RoundingMode.DOWN); // Take away some service fee by using rounding Down
        return bdAmount.doubleValue();
    }

    // Test Cases, the coder (nin) lazy to create a new class for testing
    // nin (cheng): "Just directly run the test cases here"
    /**
     * Main method to test currency exchange operations.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CurrencyExchange currency = new CurrencyExchange();
        Double exchangeRate = currency.getExchangeRate("SGD", "MYR");
        System.out.println("Exchange rate: " + exchangeRate);
        System.out.println("MOP is " + currency.getCurrencyAvailability("MOP"));
        System.out.println("WrongCurrency is " + currency.getCurrencyAvailability("WrongCurrency"));
        currency.checkExchangeRate("SGD", "MYR");
        currency.checkExchangeRate("MYR", "SGD");
        currency.checkExchangeRate("MYR", "USD");
        currency.checkExchangeRate("USD", "MYR");
        System.out.println("Lazy convert 100SGD to MYR: "+currency.convertCurrency("SGD", "MYR", 100.0));
    }

}
